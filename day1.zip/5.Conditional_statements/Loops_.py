#!/usr/bin/env python
# coding: utf-8

# In[2]:


my_list = ['p','r','o','b','l','e','m']
my_list = [3, 8, 1, 6, 0, 8, 4]
sum=0
for x in my_list:
    sum=sum+x
    print(x)
print(sum)
for fruit in ['apple','banana','mango']:
    print("I like",fruit)


# In[4]:


n = int(input("Enter num1"))
for i in range(n):
    print(i)


# In[3]:



# Output: 
# Hello John
# Hello Kate
for name in ('John','Kate'):
     print("Hello",name) 


# In[5]:


#Find the factorial of a given number n using for loop

fact = 1
n = int(input('Enter a number'))
if (n == 0) or (n == 1):
    fact = 1
    print('Factorial is ', fact)
else:
    for i in range(1,n +1):
        fact = fact * i
    print('Factorial is ', fact)


# In[7]:


#
nums = [1,2,3,4,5]
sum = 0
for n in nums:
    sum = sum + n

print("Sum =", sum)


# In[ ]:


#while programs


# In[8]:


#Program to read ‘n’ numbers and count positive, negatives and zeros among them
np = 0
nn = 0
nz = 0
counter = 1
n = int(input('Enter the total no. of numbers'))
while counter <= n:
    counter = counter + 1
    num = int(input('Enter a number'))
    if num < 0:
        nn = nn + 1
    elif num > 0:
        np = np + 1
    else:
        nz = nz + 1
print('Positive count is {0}\n Negative count is {1}\n Zeros are{2}'.format(np,nn,nz))
    


# In[ ]:




