#!/usr/bin/env python
# coding: utf-8
#Declare constants in a separate file called Const.py
#import constants file by using "import"

import Const
print(Const.PI)
print(Const.GRAVITY)

