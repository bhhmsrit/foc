
# coding: utf-8

# In[2]:


#variable
number = 10

print(number)

number=number**2

print(number)

number = "string"

print(number)

website = "apple.com"

print(website)

# assigning a new variable to website
website = "google.com"

print(website)


a, b, c = 5, 3.2, "Hello"

print (a)
print (b)
print (c)

